from django.shortcuts import render, render_to_response, get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect, Http404

def about(request):
	return render(request, 'about.html')

def contact(request):
	return render_to_response('contact.html')

def privacy(request):
	return render_to_response('privacy.html')

def team(request):
	return render_to_response('team.html')

def learn(request):
	return render_to_response('learn.html')

def file_not_found_404(request):
	return render(request, '404.html')

def server_error(request):
	return render(request, '500.html')

def perm_denied(request):
	return render(request, '403.html')